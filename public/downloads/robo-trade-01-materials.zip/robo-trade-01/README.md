# Robo Trade - บทที่ 01

สื่อการเรียนภาษาไทยที่เขียนขึ้นใหม่เพื่อเข้าใจข้อมูลราคาและสัญญาณ SMA

## เริ่มแบบออฟไลน์

1. ใช้ Python 3.11 หรือ 3.12 และสร้าง virtual environment
2. ติดตั้ง pandas==2.3.2 ด้วย pip
3. เก็บ lesson_01.py และ demo_prices.csv ไว้ในโฟลเดอร์เดียวกัน
4. รัน python lesson_01.py --short 5 --long 20
5. เปิด robo-trade-01.ipynb ด้วย Jupyter หรือ VS Code แล้วรันจากบนลงล่าง

ข้อมูล DEMO เป็น 120 แท่งรายวันสมมติ ไม่มีปฏิทินตลาดจริงและไม่มี corporate actions
สูตรราคาคือ round(100 + 0.11*i + 5.8*sin(i/9) + 1.5*sin(i/2.1), 2) สำหรับ i=0..119
ใช้ CSV ที่แนบเป็นค่ากลางเพื่อให้เว็บและ Python คำนวณจากอินพุตเดียวกัน

## อ่านข้อมูล Webull (เป็นขั้นตอนเพิ่มเติม)

- ติดตั้ง webull-openapi-python-sdk==3.0.0 ด้วย pip
- ดูการขอสิทธิ์/Market Data/2FA ที่ https://developer.webull.co.th/apis/docs/getting-started
- ตั้ง WEBULL_APP_KEY และ WEBULL_APP_SECRET บนเครื่องของคุณด้วยวิธีที่ไม่เผยข้อมูลในประวัติคำสั่ง
- รัน python webull_bars.py --fetch --environment uat --output webull_bars.json
- UAT: th-api.uat.webullbroker.com; Production: api.webull.co.th
- ใช้กุญแจตรงสภาพแวดล้อม และตรวจสิทธิ์ข้อมูล OpenAPI แยกจากแอป Webull
- สคริปต์นี้ไม่มีการส่งคำสั่งซื้อขาย และไม่เรียก API หากไม่ระบุ --fetch
- SDK อาจเปิดขั้นตอน Token/2FA ซึ่งคุณต้องดำเนินการกับ Webull เอง
- การอ่านข้อมูลจริงยังไม่ได้ทดสอบกับบัญชีของคุณ ตรวจความหมาย real_time_required และเวลาปิดแท่งก่อนใช้
- ผล JSON ต้องแปลง time เป็น UTC datetime, แปลง OHLCV เป็นตัวเลข, ตรวจ missing/duplicate และเรียงเก่าไปใหม่ก่อนคำนวณ

การเรียงเวลาไม่ได้ยืนยันว่าแท่งปิดแล้ว ตรวจ market calendar/session และ corporate actions เพิ่ม
target เป็นเป้าหมายหลังปิดแท่ง ส่วน next_open_target คือเป้าหมายที่เลื่อนหนึ่งแท่ง ไม่ใช่การยืนยัน fill
แบบฝึกหัดนี้ไม่ได้คำนวณผลตอบแทนและไม่มีหลักฐานความสามารถทำกำไร

## แหล่งอ้างอิง

- Yves Hilpisch, Python for Algorithmic Trading, บท 3-4; https://github.com/yhilpisch/py4at
- โค้ดหนังสือมีข้อจำกัดการเผยแพร่: ไม่ได้รวมโค้ดหรือ PDF ต้นฉบับในชุดไฟล์นี้
- https://developer.webull.co.th/apis/docs/sdk
- https://developer.webull.co.th/apis/docs/authentication/overview
- https://developer.webull.co.th/apis/docs/reference/trade-api/historical-bars
- https://github.com/webull-inc/webull-openapi-python-sdk

ตรวจเอกสาร 10 กันยายน 2026 สื่ออิสระ ไม่ใช่หลักสูตรที่ Webull รับรอง
